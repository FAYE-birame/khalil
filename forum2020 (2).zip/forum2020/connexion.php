<?php
$cn = mysqli_connect('localhost', 'root', '', 'forum2020');

if (!$cn) {
    die('Erreur de connexion (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
}

?>