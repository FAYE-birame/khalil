CREATE DATABASE IF NOT EXISTS forum2020;

USE forum2020;

CREATE TABLE IF NOT EXISTS utilisateur (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    nom_user VARCHAR(50) NOT NULL,
    prenom_user VARCHAR(50) NOT NULL,
    email_user VARCHAR(50) NOT NULL,
    pw_user VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS message (
    id_message INT AUTO_INCREMENT PRIMARY KEY,
    texte_message TEXT NOT NULL,
    date_message DATE NOT NULL,
    heure_message TIME NOT NULL,
    id_user INT NOT NULL,
    FOREIGN KEY (id_user) REFERENCES utilisateur(id_user)
);

